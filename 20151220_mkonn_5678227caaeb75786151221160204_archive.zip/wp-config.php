<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'mkonn');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '3k eF5K<1[[dtb/%HJ?15eWK<g9d,mM ?Y!xRaKL/#?$R%XSGA;@IS,:|kFIYQDZ');
define('SECURE_AUTH_KEY',  ' SWB([h!T*>0Qu?.^b61Jr)YG1}YBJ+%OX-HUNbiJB=(S c*OO}EQ;,loUq{:RAz');
define('LOGGED_IN_KEY',    '?$o?m5H1XU|]03UdS9<D3!b,-dy.~s`Z8PeYcGeeu37u!)#GpH#+:GuH$+)<(0Fz');
define('NONCE_KEY',        'V#254;}{l8qmH{R@t R4Ty t%PnFjzE,xI3oZem#jKG=5+(,+)iZ?#niUEhI7nZ,');
define('AUTH_SALT',        'IWcov3|s7Yqm)UacxQ esQ6q=B V`5`-<dj1dNi^]&U^Q3z$[,)rr;k3D}g$j%JV');
define('SECURE_AUTH_SALT', '1==nwjI&}7Pr9vAVt#J.Hax6xgU>%eeY&pim}+8X,PeJnNH$pdd+qI)moY>}siY`');
define('LOGGED_IN_SALT',   'TK}<QY?{]EC4/sND.K_{Y45y7vQ{!ywg}{K?)Qz90<=G<tyu}&j<Xvf9-5-_ylh1');
define('NONCE_SALT',       '_$!?$P4(IuEqC-3AYbc4Q-4YW=hKe{_+u a2Ib@WvfvfcLNmB6XW.uGOJaNlUU{*');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
